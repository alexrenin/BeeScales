This library was original code by Eric Ayars 4/1/11

Code was updated to run with Arduino IDE 1.0 By John Hubert Feb 7,2012
Examples are all still original but in an INO file.

Thank you Eric Ayars For your great work on the original code